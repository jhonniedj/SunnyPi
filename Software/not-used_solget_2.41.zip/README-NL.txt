SolGet - Logging Script voor Soladin 600.

Geschreven in Bash door Marcel Reinieren (c) 2007 - 2012

SolGet leest de Soladin 600 inverter uit via seri�le communicatie. Hiervoor worden de binaire waarden in de soladin uitgelezen, die naast de actuele opbrengst ook gegevens bevat over draaitijd, foutmeldingen, voltages, temperatuur, etc.
Het script converteert deze waarden naar leesbare data. 
Deze data wordt vervolgens op verschillende manieren weggeschreven.

- Als HTML voor het tonen op een internet site
- In een CSV bestand voor opbrengst logging
- Foutmeldingen in de soladin, of mbt communicatie worden in een logfile weggeschreven.
- In een RRDTOOL database om grafieken te genereren. (optioneel)
- In een tweet om de dagopbrengst op twitter te publiceren (optioneel)

Aan het gebruik van dit script zijn geen kosten verbonden. Solget is gepubliceerd onder de GNU General Public License. (Voor een onofici�le vertaling zie gpl-v3-NL-101.pdf)

******************************************
Benodigdheden:

Dit script is ontwikkeld op een Asus wl500g router met aangepaste linux (OLEG) firmware. Busybox 1.1.3 is gebruikt voor alle externe commando's. Gebruik op andere linux versies zal daarom vermoedelijk geen problemen geven.
De soladin 600 inverter dient via een interface (PC-Link, Sol-Link aangesloten te zijn op een COMpoort. (Of usbpoort middels usb2serial converter)
Middels cron dient het script periodiek te gestart te worden. Het script is ontworpen om iedere 5 minuten een meetwaarde op te halen. 

Voor het toegankelijk maken van de html pagina's is een webserver nodig. Er is een standaard een webserver aanwezig in de Oleg firmware. (Busybox_httpd)  Voor de Oleg firmware is het verder aan te raden om cron, nano of vi en RRDTool te installeren.

Op wl500g.info zijn voldoende HOWTO's te vinden met uitleg over hoe dit moet. Ook het aansluiten van een seri�le poort is daar veelvuldig besproken. Installatie van software, of hardware aanpassing valt buiten het bestek van deze readme.

Het script detecteert of de soladin aanstaat. Als deze niet reageert (geen reply op de compoort) zal er eenmalig een melding worden weggeschreven in de logfile. Tevens wordt de html-output in Offline mode weggeschreven.
Om 23.55 wordt de data verwerkt, en worden de waarden voor de volgende dag gereset. 

RRDTool is benodigd voor het weergeven van grafieken, SolGet is echter ook te gebruiken zonder RRDTool.
******************************************
Aan de slag:

Allereerst dienen de gebruikersvariabelen aangepast te worden in het script.
De volgende variabelen dienen correct gekozen te worden:

PORT: De compoort waar de soladin op aangesloten is. (Notatie: /dev/ttyS0)

redo: Het kan voorkomen dat de soladin niet reageert, of een slechte verbinding heeft. Met deze variabele kan aangegeven worden hoevaak een poging gedaan moet worden voordat het script met de volgende actie verder gaat. Aangeraden is om deze waarde op 3 te laten staan.

LOG: logbestand waar foutmeldingen omtrent communicatie wordt weggeschreven. (Volledige pad)

CSV: Het csv bestand waar de uitgelezen waarden worden weggeschreven. (Volledige pad)

WORKDIR: Directory waar tijdelijke bestanden geplaatst zullen worden. (Volledige pad zonder slash aan het eind)

USE_RRD: Spreekt voor zich, 0 als RRDtool niet gebruikt mag worden, 1 om RRDTOOL te gebruiken.

RRDDIR: Locatie waar de RRDTOOL database geplaatst wordt. (Volledige pad zonder slash aan het eind)

GRAPHDIR: Locatie waar grafieken worden weggeschreven als PNG bestand. (Volledige pad zonder slash aan het eind)

WtotOffset: Deze waarde kan gebruikt worden om een aangepaste output te tonen op de HTML pagina. (bv bij plaatsing van een nieuwe/andere soladin) Zowel positieve als negatieve correcties worden ondersteund. Deze waarde moet met 100 vermenigvuldigd worden. Een offset van 1245,36kWh moet als 124536 weggeschreven worden. Deze waarde be�nvloed niet de waarde in de CSV file.

USE_TWITTER: Standaard op 0. Wil je een dagelijkse tweet met de opgeleverde energie, zet deze waarde dan op 1
username: Twitter gebruikersnaam
password: TWitter password

Maak de opgegeven directory's aan met mkdir indien dit nog niet gebeurd is.

LET OP: Zorg ervoor dat de BASH interpreter juist staat. Op veel embedded linux apparaten is dit /opt/bin/bash, zoals in het script is ingesteld. Op een normale linux distributie moet dit /bin/bash zijn. Pas in dat geval de eerste regel aan.

Nadat deze variabelen zijn ingevuld, dient de csv file aangemaakt te worden, en eventueel de RRDTool database.

Dit gebeurt met het commando: solget.sh create

Indien het aanmaken succesvol is verlopen, wordt er geen melding getoond.

De voorbereidingen zijn nu gereed.
******************************************
Het draaien van het script

Maak een regel aan in de cron configuratie (bv /opt/etc/crontab)

*/5 * * * * root /opt/usr/bin/solget.sh

Waarbij root het admin account dient te zijn, en uiteraard het pad juist dient te zijn.

Indien er tijdens communicatie fouten zijn opgetreden, wordt dit weggeschreven in het logbestand. Dit logbestand wordt pas aangemaakt nadat er voor het eerst een fout wordt gedetecteerd, of een melding wordt weggeschreven.
******************************************

SUPPORT:

Bij vragen, opmerkingen of problemen, plaats deze op facebook (www.facebook.com/Solget.nl) het forum, mail (mail@solget.nl) of schrijf een bericht via mijn website (www.solget.nl).


Bedankt voor het gebruiken van Solget!


Wil je mij bedanken, overweeg dan eens een donatie. Dit kan via de Donatieknop (via PayPal) op mijn website. (www.solget.nl)